#pragma once

//Char Pointer
#define cp (char*)
//No Register
#define nr -1


extern Token currentToken;